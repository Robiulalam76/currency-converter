export const primaryGrad = [
  "rgba(90, 67, 255, 0.97)",
  "rgba(78, 67, 255, 0.97)",
  "rgba(255, 255, 255, 0.2)",
];
