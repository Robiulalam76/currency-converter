const OnBoardingData = [
  {
    id: 1,
    title: "Manage your Salary Easily",
    description:
      "This app creates a budget based on your salary and family member. This helps you to stay in control of your money.",
    image:
      "https://images.unsplash.com/photo-1641862039942-5815d8f74938?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
  {
    id: 2,
    title: "Track your Expenses",
    description: "Keep track of the areras where you spend your money",
    image:
      "https://images.unsplash.com/photo-1641862039942-5815d8f74938?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
  {
    id: 3,
    title: "Get savings Tips",
    description:
      "You can generate ideas about the best ways to save money in your day-to-day life using these money-saving tips.",
    image:
      "https://images.unsplash.com/photo-1641862039942-5815d8f74938?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
  {
    id: 4,
    title: "Get savings Tips ",
    description:
      "You can generate ideas about the best ways to save money in your day-to-day life using these money-saving tips.",
    image:
      "https://images.unsplash.com/photo-1641862039942-5815d8f74938?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80",
  },
];

export default OnBoardingData;
