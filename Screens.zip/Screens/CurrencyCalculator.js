import { StyleSheet, View } from "react-native";
import React from "react";
import {
  Box,
  Center,
  CheckIcon,
  HStack,
  Input,
  Select,
  Text,
  VStack,
} from "native-base";

const CurrencyCalculator = () => {
  const [service, setService] = React.useState("");

  return (
    <View>
      <Text>CurrencyCalculator page</Text>
    </View>
  );
};

export default CurrencyCalculator;

const styles = StyleSheet.create({});
